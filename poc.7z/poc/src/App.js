import React, { useState } from 'react';
import { Box, CssBaseline } from '@mui/material';
import Header from './components/Header';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';
import GraphTab from './components/GraphTab';

function App() {
  const [tabs, setTabs] = useState([]);
  const [tabIndex, setTabIndex] = useState(0);

  const addNewTab = (tab) => {
    setTabs((prev) => [...prev, tab]);
    setTabIndex(tabs.length);
  };

  return (
    <>
      <CssBaseline />
      <Header />
      <Box display="flex" height="calc(100vh - 112px)">
        <Box width="300px" borderRight="1px solid #ccc" overflow="auto">
          <Chatbot onNewTab={addNewTab} />
        </Box>
        <Box flexGrow={1} overflow="hidden">
         
        </Box>
      </Box>
      <Footer />
    </>
  );
}

export default App;
