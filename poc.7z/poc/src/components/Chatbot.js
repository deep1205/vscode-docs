import React, { useEffect, useState } from 'react';
import { Box, TextField, Button, Typography } from '@mui/material';
import io from 'socket.io-client';
import { transformQuery } from '../utils/transformQuery';

const socket = io('http://localhost:3001');

const Chatbot = ({ onNewTab }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    socket.on('bot_response', (data) => {
      setMessages((prev) => [...prev, { sender: 'bot', text: data.text }]);
      if (data.graphData) {
        onNewTab({
          id: Date.now().toString(),
          label: data.graphData.title,
          graphData: data.graphData
        });
      }
    });
  }, [onNewTab]);

  const handleSend = () => {
    if (input.trim()) {
      const query = transformQuery(input);
      setMessages((prev) => [...prev, { sender: 'user', text: input }]);
      socket.emit('user_message', { text: query });
      setInput('');
    }
  };

  return (
    <Box p={2}>
      <Box height="70vh" overflow="auto">
        {messages.map((msg, i) => (
          <Typography key={i} color={msg.sender === 'bot' ? 'green' : 'blue'}>
            {msg.sender}: {msg.text}
          </Typography>
        ))}
      </Box>
      <TextField
        fullWidth
        size="small"
        placeholder="Ask something..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        sx={{ mt: 1 }}
      />
      <Button fullWidth variant="contained" onClick={handleSend} sx={{ mt: 1 }}>
        Send
      </Button>
    </Box>
  );
};

export default Chatbot;
