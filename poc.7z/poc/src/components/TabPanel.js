import React from 'react';
import { Box } from '@mui/material';

const TabPanel = ({ children, value, index }) => (
  <div hidden={value !== index}>
    {value === index && <Box p={2}>{children}</Box>}
  </div>
);

export default TabPanel;
