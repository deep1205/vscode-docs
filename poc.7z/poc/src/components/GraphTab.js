import React from 'react'

const GraphTab = () => {
  return (
    <div>GraphTab</div>
  )
}

export default GraphTab