export const transformQuery = (input) => {
  return input.toLowerCase().trim();
};
